Inflador con archivo.h que incluye la cabecera de cada función y una breve explicación de que hace cada una,  además cada acción es visible con un mensaje en la terminal.


Funcionamiento del Sistema
Al encender el sistema, se inicializan los periféricos, incluyendo los sensores de presión y temperatura, y la pantalla LCD.
Se muestra un mensaje de bienvenida en la pantalla LCd

Ajuste de la Presión Deseada, se enciende el LED  RA0 (ELECCIÓN)
Posteriormente el sistema permite ajustar la presión deseada mediante botones conectados a los pines RC0, RC1 y RC2 del microcontrolador o bien wasd de la terminal, con una animación de los botones en pantalla.
RC0: Aumenta la presión en 1 PSI.
RC1: Disminuye la presión en 1 PSI.
RC2: Fija la presión deseada y procede a la etapa de inflado.

Lectura de Sensores
El sistema lee los valores de los sensores de presión y temperatura. La temperatura afecta la duración del inflado y la potencia del compresor.
Los valores de temperatura y presión se muestran en la pantalla LCD.


Control del Compresor
Se calcula la duración del inflado en función de la diferencia entre la presión deseada y la presión inicial, así como de la temperatura ambiente.

El compresor se activa con un ciclo de trabajo PWM que varía según la presión y la temperatura. Se utilizan valores de PWM entre 40% y 95% dependiendo de la presión deseada


Inflado y Desinflado, se enciende el LED  RA1 (EN PROGRESO)
El sistema ajusta la presión del inflador incrementando o disminuyendo gradualmente la presión interna hasta alcanzar la presión deseada.
Se muestra un mensaje en la pantalla LCD indicando el estado del inflado (inflando o desinflando).

 Finalización, se enciende el LED  RA1 (FINALIZADO)
Si el usuario presiona un botón de emergencia o si hay una pinchada(adc anterior != adc atual), el sistema entra en modo de parada de emergencia.
El compresor se detiene inmediatamente y se muestra un mensaje de parada de emergencia en la pantalla LCD, vuelve a su estado inicial.

Por otro lado una vez que se alcanza la presión deseada, el compresor se apaga y se muestra un mensaje de "Presión ajustada" en la pantalla LCD.



**Problemas Encontrados**

TMR0:Está configurado para que lance una interrupción cada segundo, aunque no sabemos porque en pantalla tarda más de un segundo en actualizarse, el TMR0  está configurado correctamente con las f´romulas adientes.

Problema UART: al entrar en la interrupción y comprobar cual era la tecla pulsada, por ejemplo la d que es la que aumenta la presión, pues detectaba todo el rato la 'd' y por lo tanto entraba en un bucle infinito incrementando.
Solución: cada vez que se lee un char, se pone a 0 la variable que guarda la tecla para que no vuelva a leer el mismo.

La fórmula para calcular la presión deseada estaba genera resultados incorrectos debido a un error de tipo de datos, ya que los sensores miden bien la presión y temperatura 
Solución intentada: Hemos intentado probar con todos los tipos de datos y ninguno hace bien la fórmula.

La bandera de interrupción no se limpiaba adecuadamente, lo que provocaba que el sistema se interrumpiera continuamente.
Solución: Se agregó  (INTCONbits.INT0IF = 0) para asegurar que las interrupciones se manejen solo una vez por evento.

Problemas con el PWM:
Al prinicippio, teníamos configurado como CCP2, y no me había dado cuenta que ese puerto ya estaba usado por los botones, así que cambiamos la configuración y buscamos un pin libre, en este caso el RE2, CCP5.

